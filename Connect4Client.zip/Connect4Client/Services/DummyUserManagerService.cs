﻿using Czeum.Client.Interfaces;
using Czeum.DTO.UserManagement;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Czeum.Client.Services
{
    class DummyUserManagerService : IUserManagerService
    {
        public string AccessToken => throw new NotImplementedException();

        public async Task ChangePasswordAsync(ChangePasswordModel data)
        {
            throw new NotImplementedException();
        }

        public async Task LoginAsync(LoginModel data)
        {
            throw new NotImplementedException();
        }

        public async Task RegisterAsync(RegisterModel data)
        {
            throw new NotImplementedException();
        }
    }
}
