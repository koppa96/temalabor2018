﻿using Czeum.Client.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Prism.Windows.Mvvm;
using System.ComponentModel;

namespace Czeum.Client.ViewModels
{
    class LoginPageViewModel : ViewModelBase, ILoginPageViewModel, INotifyPropertyChanged
    {
        private String _Name;
        public String Name {
            get { return _Name; }
            set { SetProperty(ref _Name, value);  }
        }

        private String m_Password;
        public String Password { 
			get { return m_Password; }
            set { SetProperty(ref m_Password, value); }
		}


        private String _ConfirmPassword;
        public String ConfirmPassword {
			get { return _ConfirmPassword; }
            set {SetProperty(ref _ConfirmPassword, value); }
		}


        private String _Email;
        public String Email
        {
            get { return _Email; }
            set { SetProperty(ref _Email, value); }
        }
    }
}
